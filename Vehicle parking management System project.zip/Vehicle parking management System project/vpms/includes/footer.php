  <footer class="site-footer">
      <div class="footer-inner bg-white">
          <div class="row">
              <div class="col-sm-6">
                  Copyright &copy; 2022
              </div>
              <div class="col-sm-6 text-right">
                  Car Parking
              </div>
          </div>
      </div>
  </footer>

