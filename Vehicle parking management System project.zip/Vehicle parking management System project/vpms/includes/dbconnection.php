<?php
$con = mysqli_connect("localhost", "root","", "car parking");
if (mysqli_connect_errno()) {
  echo "Connection Fail" . mysqli_connect_error();
}
//rabt krdny databaseakaman ba webakamanawa ka variable $con bangy dakaynawa lanaw pageakany webakama bo away rabt bet peyawa
